import os; os.environ['PYOPENGL_PLATFORM'] = 'egl'
import numpy as np
np.infty = np.inf
import pyrender, trimesh
from PIL import Image

def look(eye, tgt, up=(0, 1, 0)):
    eye = np.asarray(eye, float); f = np.asarray(tgt, float) - eye; f /= np.linalg.norm(f)
    r = np.cross(f, up); r /= np.linalg.norm(r); u = np.cross(r, f)
    M = np.eye(4); M[:3, 0] = r; M[:3, 1] = u; M[:3, 2] = -f; M[:3, 3] = eye; return M

def rover_mesh():
    s = trimesh.load(os.environ.get('ROVER_GLB', 'Space_Exploration_Vehicle.glb'))
    node = s.graph.nodes_geometry[0]; T, g = s.graph[node]; m = s.geometry[g].copy()
    m.apply_transform(T)
    tex = m.visual.material.baseColorTexture.convert('RGB').resize((2048, 2048))
    tx = pyrender.Texture(source=np.ascontiguousarray(np.asarray(tex, dtype=np.uint8)), source_channels='RGB')
    mat = pyrender.MetallicRoughnessMaterial(baseColorTexture=tx, metallicFactor=0.1, roughnessFactor=0.7)
    prim = pyrender.Primitive(positions=m.vertices.astype(np.float32), normals=m.vertex_normals.astype(np.float32),
                              texcoord_0=m.visual.uv.astype(np.float32), indices=m.faces.astype(np.uint32), material=mat)
    return pyrender.Mesh([prim]), m.bounds
