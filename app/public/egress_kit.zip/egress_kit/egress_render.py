import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from egress_scene import *

FPS = 24
W, Hpx = 1152, 720
SS = 1.5
RW, RH = int(W * SS), int(Hpx * SS)
T_A, T_B, T_C, T_D = 3.6, 3.0, 1.7, 3.4
TOTAL = T_A + T_B + T_C + T_D

def ease_out(t): return 1 - (1 - t) ** 3
def ease_io(t): return t * t * (3 - 2 * t)
def ease_in(t): return t ** 2.2
def lerp(a, b, t): return np.asarray(a) * (1 - t) + np.asarray(b) * t

M_END = rover_pose(LEN)
SUN = np.array([-0.94 * np.cos(np.radians(32)), np.sin(np.radians(32)), -0.34 * np.cos(np.radians(32))]); SUN /= np.linalg.norm(SUN)
S0 = LEN - 58

def ground(x, z): return hgt(x, z)[0]

# ---------- dust ----------
def dust_particles(t):
    out = []
    prng = np.random.default_rng(11)
    n_emit = int(T_A * 60)
    for i in range(n_emit):
        te = i / 60.0
        k = prng.random(8)
        if te > t: continue
        u = min(te / 3.2, 1)
        if u >= 1: continue
        speed = 1 - u  # emission fades as rover stops
        if k[0] > speed * 1.1: continue
        s = S0 + (LEN - S0) * ease_out(u)
        M = rover_pose(s)
        side = 1.75 if k[1] > 0.5 else -1.75
        p0 = to_world(M, [side, -2.05, -2.3 + k[2] * 1.0])
        back = -M[:3, 2]
        v = back * (0.8 + 1.2 * k[3]) * speed + M[:3, 0] * side * 0.25 + np.array([0, 0.45 + 0.5 * k[4], 0])
        v += np.array([0.35, 0, 0.12])  # light wind
        age = t - te
        life = 2.6 + 1.5 * k[5]
        if age > life: continue
        drag = (1 - np.exp(-1.2 * age)) / 1.2
        p = p0 + v * drag + np.array([0, -0.06, 0]) * age ** 2
        size = 0.35 + 1.7 * (age / life) ** 0.6
        a = 0.20 * speed * (1 - age / life) ** 1.5 * (0.6 + 0.4 * k[6])
        out.append((p, size, a))
    return out

# ---------- camera timeline ----------
def shot(t):
    """returns (pose, yfov, rover_s, beacon_on, extra)"""
    ex = {'fade': 0.0, 'expo': 1.0}
    if t < T_A:
        u = t / T_A
        s = S0 + (LEN - S0) * ease_out(min(t / 3.2, 1))
        M = rover_pose(s)
        pe = M_END[:3, 3]
        cam = pe + M_END[:3, 2] * 13 + M_END[:3, 0] * 9.5
        cam = cam + M_END[:3, 2] * (-1.5 * u)
        cam[1] = ground(cam[0], cam[2]) + 1.05
        tgt = M[:3, 3] + np.array([0, -0.6, 0])
        ex['fade'] = max(0, 1 - t / 0.5)
        return look(cam, tgt), np.radians(21 - 2 * u), s, None, ex
    t -= T_A
    DOOR = np.array([2.0, 0.2, 0.0])
    if t < T_B:
        u = ease_io(t / T_B)
        a = np.radians(lerp(52, 90, u))
        r = lerp(12.5, 9.5, u)
        pe = M_END[:3, 3]
        cam = pe + M_END[:3, 0] * np.sin(a) * r + M_END[:3, 2] * np.cos(a) * r
        cam[1] = ground(cam[0], cam[2]) + lerp(1.2, 2.2, u)
        tgt = lerp(pe + np.array([0, -0.6, 0]), to_world(M_END, [1.2, 0.0, 0.0]), u)
        return look(cam, tgt), np.radians(lerp(26, 30, u)), LEN, 'amber', ex
    t -= T_B
    if t < T_C:
        u = t / T_C
        e = ease_in(u)
        door = to_world(M_END, DOOR)
        pe = M_END[:3, 3]
        start = pe + M_END[:3, 0] * 9.5
        start[1] = ground(start[0], start[2]) + 2.2
        endp = to_world(M_END, DOOR + np.array([0.75, 0, 0]))
        cam = lerp(start, endp, e)
        tgt = lerp(to_world(M_END, [1.2, 0.0, 0.0]), door, min(1, u * 1.5))
        ex['fade'] = np.clip((u - 0.78) / 0.22, 0, 1)
        return look(cam, tgt), np.radians(lerp(30, 40, e)), LEN, ('green' if u > 0.25 else 'amber'), ex
    t -= T_C
    # first person, stepping out of the side hatch
    L = lambda p: to_world(M_END, p)
    key_t = [0.0, 0.45, 1.3, 2.4, T_D]
    key_x = [2.75, 3.3, 4.1, 4.5, 4.6]
    key_z = [0.0, 0.25, 1.1, 2.6, 4.4]
    px = np.interp(t, key_t, key_x); pz = np.interp(t, key_t, key_z)
    pos = L([px, 0, pz])
    step = np.clip(t / 0.55, 0, 1)
    eye_h = lerp(2.3, 1.72, ease_io(step)) - 0.09 * np.exp(-((t - 0.62) / 0.12) ** 2)
    walking = np.clip((t - 0.5) / 0.4, 0, 1)
    bob = 0.035 * np.sin(t * 2 * np.pi * 1.9) * walking
    pos[1] = ground(pos[0], pos[2]) + eye_h + bob
    yaw = np.radians(lerp(90, -4, ease_io(np.clip((t - 0.5) / 2.1, 0, 1))))
    fwd = M_END[:3, 0] * np.sin(yaw) + M_END[:3, 2] * np.cos(yaw)
    fwd = fwd - M_END[:3, 1] * fwd.dot(M_END[:3, 1]); fwd /= np.linalg.norm(fwd)
    pitch = np.radians(lerp(-16, -4, ease_io(np.clip(t / 1.5, 0, 1))))
    fwd = fwd * np.cos(pitch) + np.array([0, np.sin(pitch), 0])
    roll = 0.012 * np.sin(t * 2 * np.pi * 0.95) * walking
    up = np.array([0, 1, 0]) + np.cross(fwd, [0, 1, 0]) * roll
    ex['fade'] = max(0, 1 - t / 0.35)
    ex['expo'] = 1 + 0.9 * np.exp(-t / 0.45)
    return look(pos, pos + fwd, up), np.radians(52), LEN, None, ex

# ---------- post ----------
def ray_dirs(pose, yfov):
    f = (RH / 2) / np.tan(yfov / 2)
    xs = (np.arange(RW) - RW / 2 + 0.5) / f; ys = -(np.arange(RH) - RH / 2 + 0.5) / f
    X, Y = np.meshgrid(xs, ys)
    d = X[..., None] * pose[:3, 0] + Y[..., None] * pose[:3, 1] - pose[:3, 2]
    return d / np.linalg.norm(d, axis=-1, keepdims=True)

SKY_H = np.array([0.36, 0.22, 0.14]); SKY_T = np.array([0.03, 0.02, 0.02]); FOG = np.array([0.33, 0.21, 0.14])

def post(color, depth, pose, yfov, parts, ex, shadow=None):
    img = color[..., :3].astype(np.float32) / 255.0
    d = ray_dirs(pose, yfov)
    if shadow is not None:
        sdep, Lpose, mag, rpose = shadow
        cosz = (d * -pose[:3, 2]).sum(-1)
        wp = pose[:3, 3] + d * (depth / np.maximum(cosz, 1e-3))[..., None]
        Li = np.linalg.inv(Lpose)
        q = wp @ Li[:3, :3].T + Li[:3, 3]
        n = sdep.shape[0]
        uu = ((q[..., 0] / mag) * 0.5 + 0.5) * (n - 1); vv = ((-q[..., 1] / mag) * 0.5 + 0.5) * (n - 1)
        inb = (uu >= 0) & (uu < n - 1) & (vv >= 0) & (vv < n - 1) & (depth > 0)
        sd = ndimage.map_coordinates(sdep, [np.clip(vv, 0, n - 1), np.clip(uu, 0, n - 1)], order=0)
        occ = inb & (sd > 0) & (-q[..., 2] > sd + 0.25)
        mask = ndimage.gaussian_filter(occ.astype(np.float32), 2.0)
        # contact occlusion under the chassis
        Ri = np.linalg.inv(rpose)
        lq = wp @ Ri[:3, :3].T + Ri[:3, 3]
        dx = np.maximum(np.abs(lq[..., 0]) - 1.6, 0); dz = np.maximum(np.abs(lq[..., 2]) - 2.9, 0)
        ao = np.exp(-np.hypot(dx, dz) / 0.9) * np.clip((-1.7 - lq[..., 1]) / 0.4, 0, 1) * (depth > 0)
        ao = ndimage.gaussian_filter(ao, 1.5)
        img = img * (1 - 0.5 * mask[..., None]) * (1 - 0.45 * ao[..., None])
    el = d[..., 1]
    sky = SKY_H + (SKY_T - SKY_H) * np.clip(el / 0.45, 0, 1)[..., None] ** 0.6
    m = (depth == 0)[..., None]
    fog = (1 - np.exp(-depth / 1300.0))[..., None]
    img = img * (1 - fog) + FOG * fog
    img = np.where(m, sky, img)
    # dust
    if parts:
        f = (RH / 2) / np.tan(yfov / 2)
        inv = np.linalg.inv(pose)
        dc = np.array([0.62, 0.45, 0.33])
        acc = np.zeros(img.shape[:2], np.float32)
        for p, size, a in parts:
            q = inv @ np.r_[p, 1]
            z = -q[2]
            if z < 0.5: continue
            sx = RW / 2 + q[0] * f / z; sy = RH / 2 - q[1] * f / z
            rp = size * f / z
            x0, x1 = int(max(0, sx - 2 * rp)), int(min(RW, sx + 2 * rp)); y0, y1 = int(max(0, sy - 2 * rp)), int(min(RH, sy + 2 * rp))
            if x0 >= x1 or y0 >= y1: continue
            yy, xx = np.mgrid[y0:y1, x0:x1]
            g = np.exp(-(((xx - sx) ** 2 + (yy - sy) ** 2) / (rp * rp)))
            zb = depth[y0:y1, x0:x1]
            vis = np.where((zb == 0) | (zb > z - size * 0.5), 1.0, 0.0)
            acc[y0:y1, x0:x1] += g * vis * a
        acc = np.clip(acc, 0, 0.85)[..., None]
        img = img * (1 - acc) + dc * acc
    img = img * ex['expo'] * 1.22
    # bloom
    br = np.clip(img - 0.75, 0, None)
    img = img + ndimage.gaussian_filter(br, (RH / 60, RH / 60, 0)) * 0.9
    # filmic-ish curve
    img = img / (1 + 0.25 * img)
    img = img * 1.25
    # vignette
    yy, xx = np.mgrid[0:RH, 0:RW]
    r2 = ((xx - RW / 2) / (RW / 2)) ** 2 + ((yy - RH / 2) / (RH / 2)) ** 2
    img = img * (1 - 0.32 * r2[..., None] ** 1.3)
    img = img * (1 - ex['fade'])
    img = np.clip(img, 0, 1)
    out = Image.fromarray((img * 255).astype(np.uint8)).resize((W, Hpx), Image.LANCZOS)
    a = np.asarray(out).astype(np.float32)
    a += np.random.default_rng().normal(0, 2.2, a.shape)
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8))

def main(frames=None, outdir='egress_frames'):
    os.makedirs(outdir, exist_ok=True)
    sc, rover, bnode, lamps = build_scene()
    cam = pyrender.PerspectiveCamera(yfov=0.5, znear=0.08, zfar=4000)
    cn = sc.add(cam, pose=np.eye(4))
    ln = sc.add(pyrender.OrthographicCamera(xmag=11.0, ymag=11.0, znear=1, zfar=140), pose=np.eye(4))
    sc.main_camera_node = cn
    r = pyrender.OffscreenRenderer(RW, RH)
    n = int(TOTAL * FPS)
    frames = range(n) if frames is None else frames
    for i in frames:
        t = i / FPS
        pose, yfov, s, beacon, ex = shot(t)
        cam.yfov = yfov
        sc.set_pose(cn, pose)
        sc.set_pose(rover, rover_pose(s))
        rp = rover_pose(s)
        sc.set_pose(rover, rp)
        on = beacon == 'green' or (beacon == 'amber' and (t * 1.4) % 1 < 0.4)
        lp = np.r_[np.c_[np.eye(3), to_world(rp, [1.42, 0.62, -1.12])], [[0, 0, 0, 1]]]
        for k, nd in lamps.items():
            sc.set_pose(nd, lp if (on and k == beacon) else FAR)
        bnode.light.color = np.array([0.35, 1.0, 0.55]) if beacon == 'green' else np.array([1.0, 0.6, 0.15])
        bnode.light.intensity = 6.0 if on else 0.0
        sc.set_pose(bnode, np.r_[np.c_[np.eye(3), to_world(rp, [2.1, 0.7, -0.8])], [[0, 0, 0, 1]]])
        # shadow pass: tight orthographic depth map from the sun around the rover
        Lpose = look(rp[:3, 3] + SUN * 60, rp[:3, 3])
        sc.main_camera_node = ln; sc.set_pose(ln, Lpose)
        r.viewport_width, r.viewport_height = 2048, 2048
        sdep = r.render(sc, flags=pyrender.RenderFlags.DEPTH_ONLY)
        nz, fz = 1.0, 140.0
        valid = sdep > 0
        zn = (fz + nz - 2 * nz * fz / np.where(valid, sdep, 1)) / (fz - nz)
        sdep = np.where(valid, nz + (zn + 1) / 2 * (fz - nz), 0).astype(np.float32)
        sc.main_camera_node = cn
        r.viewport_width, r.viewport_height = RW, RH
        c, d = r.render(sc)
        parts = dust_particles(t) if t < T_A + 1.5 else []
        post(c, d, pose, yfov, parts, ex, (sdep, Lpose, 11.0, rp)).save(f'{outdir}/f{i:04d}.png')
        print(i, round(t, 2), flush=True)

if __name__ == '__main__':
    if len(sys.argv) > 1:
        main([int(x) for x in sys.argv[1:]], 'egress_test')
    else:
        main()
