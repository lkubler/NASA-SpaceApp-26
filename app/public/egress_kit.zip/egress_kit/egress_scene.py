import os, sys, json; os.environ['PYOPENGL_PLATFORM'] = 'egl'
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, trimesh, pyrender
from PIL import Image
from scipy import ndimage, interpolate
from rover_lib import rover_mesh, look

EX = 1.6
H = np.load('h.npy').astype(np.float64) * EX
Hh, Ww = H.shape
COL = np.clip(np.asarray(Image.open('map_base.png'), np.float32) / 255.0 * 1.35, 0, 1)
P = json.load(open('plan.json'))
HAND = np.array(P['hand'], float)
rng = np.random.default_rng(7)

def hgt(x, z):
    return ndimage.map_coordinates(H, [np.atleast_1d(z), np.atleast_1d(x)], order=1, mode='nearest')

def grad(x, z, e=1.5):
    gx = (hgt(x + e, z) - hgt(x - e, z)) / (2 * e); gz = (hgt(x, z + e) - hgt(x, z - e)) / (2 * e)
    return gx, gz

def normal(x, z):
    gx, gz = grad(x, z)
    n = np.stack([-gx, np.ones_like(gx), -gz], -1); return n / np.linalg.norm(n, axis=-1, keepdims=True)

def terrain_mesh(x0, x1, z0, z1, step, hole=None, drop=0.0):
    xs = np.arange(x0, x1 + 1e-6, step); zs = np.arange(z0, z1 + 1e-6, step)
    X, Z = np.meshgrid(xs, zs)
    Y = ndimage.map_coordinates(H, [Z.ravel(), X.ravel()], order=3, mode='nearest').reshape(X.shape)
    # fine relief so close shots are not glassy
    fine = ndimage.gaussian_filter(rng.standard_normal(X.shape), 1.2) * (0.10 / step if step < 1 else 0.05)
    Y = Y + fine - drop
    nx, nz = len(xs), len(zs)
    idx = np.arange(nx * nz).reshape(nz, nx)
    a = idx[:-1, :-1].ravel(); b = idx[:-1, 1:].ravel(); c = idx[1:, :-1].ravel(); d = idx[1:, 1:].ravel()
    faces = np.concatenate([np.stack([a, c, b], 1), np.stack([b, c, d], 1)])
    if hole is not None:
        cxs = X.ravel()[faces].mean(1); czs = Z.ravel()[faces].mean(1)
        hx0, hx1, hz0, hz1 = hole
        keep = ~((cxs > hx0) & (cxs < hx1) & (czs > hz0) & (czs < hz1)); faces = faces[keep]
    V = np.stack([X.ravel(), Y.ravel(), Z.ravel()], 1)
    m = trimesh.Trimesh(V, faces, process=False)
    nrm = m.vertex_normals
    slope = np.degrees(np.arccos(np.clip(nrm[:, 1], -1, 1)))
    base = np.stack([ndimage.map_coordinates(COL[..., k], [V[:, 2], V[:, 0]], order=1, mode='nearest') for k in range(3)], 1)
    grain = 0.9 + 0.2 * ndimage.gaussian_filter(rng.random(X.shape), 0.6).ravel()
    base = base * grain[:, None]
    patch = ndimage.gaussian_filter(np.random.default_rng(5).standard_normal(X.shape), 6.0 / step)
    patch = patch / (patch.std() + 1e-6)
    base = base * (1 + 0.10 * patch.ravel())[:, None] + np.array([0.05, 0.03, 0.015]) * np.clip(patch.ravel(), 0, None)[:, None]
    wh = V[:, 1]
    strata = 0.80 + 0.16 * np.sin(wh / EX * 1.1 + 0.8 * np.sin(wh / EX * 0.37)) + 0.06 * np.sin(wh / EX * 4.3)
    wallc = np.array([0.66, 0.44, 0.30])[None] * strata[:, None]
    w = np.clip((slope - 28) / 18, 0, 1)[:, None]
    colr = np.clip(base * (1 - w) + wallc * w, 0, 1)
    prim = pyrender.Primitive(positions=V.astype(np.float32), normals=nrm.astype(np.float32), indices=faces.astype(np.uint32),
                              color_0=np.concatenate([colr, np.ones((len(V), 1))], 1).astype(np.float32),
                              material=pyrender.MetallicRoughnessMaterial(baseColorFactor=[1, 1, 1, 1], metallicFactor=0, roughnessFactor=1))
    return pyrender.Mesh([prim])

def rocks_mesh(center, radius, n, avoid):
    parts = []; cols = []
    base = trimesh.creation.icosphere(subdivisions=2)
    tries = 0
    while len(parts) < n and tries < n * 20:
        tries += 1
        r = radius * np.sqrt(rng.random()); a = rng.random() * 2 * np.pi
        x, z = center[0] + r * np.cos(a), center[1] + r * np.sin(a)
        if min(np.min(np.hypot(av[:, 0] - x, av[:, 1] - z)) for av in avoid) < 4.0: continue
        s = 0.06 + rng.pareto(2.2) * 0.16
        s = min(s, 1.8)
        m = base.copy()
        v = m.vertices * np.array([1, 0.55 + 0.3 * rng.random(), 0.7 + 0.5 * rng.random()])
        v += rng.normal(0, 0.12, v.shape)
        R = trimesh.transformations.random_rotation_matrix(rng.random(3))[:3, :3]
        R = trimesh.transformations.rotation_matrix(rng.random() * 6.28, [0, 1, 0])[:3, :3]
        v = (v * s) @ R.T
        y = hgt(x, z)[0]
        v += np.array([x, y - s * 0.25, z])
        m.vertices = v; parts.append(m)
        tone = np.array([0.36, 0.22, 0.15]) * (0.75 + 0.5 * rng.random())
        cols.append(np.tile(tone, (len(v), 1)))
    M = trimesh.util.concatenate(parts)
    C = np.concatenate(cols)
    prim = pyrender.Primitive(positions=M.vertices.astype(np.float32), normals=M.vertex_normals.astype(np.float32),
                              indices=M.faces.astype(np.uint32), color_0=np.concatenate([C, np.ones((len(C), 1))], 1).astype(np.float32),
                              material=pyrender.MetallicRoughnessMaterial(baseColorFactor=[1, 1, 1, 1], metallicFactor=0, roughnessFactor=1))
    return pyrender.Mesh([prim])

# ---------- route spline ----------
R = np.array(P['rover'], float)
seg = np.r_[0, np.cumsum(np.hypot(*np.diff(R, axis=0).T))]
keep = np.r_[True, np.diff(seg) > 0.5]
R, seg = R[keep], seg[keep]
tck, _ = interpolate.splprep([R[:, 0], R[:, 1]], u=seg, s=len(R) * 6)
LEN = seg[-1]
def route_at(s):
    x, z = interpolate.splev(s, tck); dx, dz = interpolate.splev(s, tck, der=1)
    return np.array([x, z]), np.array([dx, dz]) / np.hypot(dx, dz)

ROVER_LIFT = 2.24
def rover_pose(s):
    p, d = route_at(s)
    x, z = p
    # average ground under the wheelbase
    pts = [(x + d[0] * o, z + d[1] * o) for o in (-2.2, 0, 2.2)]
    y = np.mean([hgt(a, b)[0] for a, b in pts])
    up = normal(np.array([x]), np.array([z]))[0]; up = 0.5 * up + 0.5 * np.array([0, 1, 0]); up /= np.linalg.norm(up)
    fwd = np.array([d[0], 0, d[1]]); fwd -= up * fwd.dot(up); fwd /= np.linalg.norm(fwd)
    right = np.cross(up, fwd)
    M = np.eye(4); M[:3, 0] = right; M[:3, 1] = up; M[:3, 2] = fwd; M[:3, 3] = np.array([x, y, z]) + up * ROVER_LIFT
    return M

def to_world(M, local):
    return (M @ np.r_[local, 1])[:3]

def build_scene(include_far=True):
    sc = pyrender.Scene(ambient_light=[0.34, 0.25, 0.20], bg_color=[0, 0, 0, 0])
    hx, hz = HAND
    near = (hx - 140, hx + 140, hz - 120, hz + 120)
    sc.add(terrain_mesh(*near, 0.5))
    if include_far:
        sc.add(terrain_mesh(max(0, hx - 700), min(Ww - 1, hx + 700), max(0, hz - 400), min(Hh - 1, hz + 500), 3.0,
                            hole=(near[0] + 3, near[1] - 3, near[2] + 3, near[3] - 3), drop=0.03))
    walk = np.array(P['walk'], float)[:40]
    rv = np.array([route_at(s)[0] for s in np.linspace(LEN - 140, LEN, 60)])
    sc.add(rocks_mesh(HAND, 95, 2600, [rv, walk]))
    rm, rb = rover_mesh()
    rover = sc.add(rm, pose=np.eye(4))
    # sun: low, from the west-north-west, warm
    sd = np.array([-0.94, 0.0, -0.34]); sd = sd / np.linalg.norm(sd) * np.cos(np.radians(32)); sd[1] = np.sin(np.radians(32))
    sun = pyrender.DirectionalLight(color=[1.0, 0.86, 0.70], intensity=7.5)
    sc.add(sun, pose=look(HAND_W() + sd * 50, HAND_W()))
    # sky fill
    sc.add(pyrender.DirectionalLight(color=[0.85, 0.62, 0.48], intensity=0.9), pose=look(HAND_W() + np.array([40, 60, 30]), HAND_W()))
    beacon = pyrender.PointLight(color=[1.0, 0.55, 0.15], intensity=0.0)
    bnode = sc.add(beacon, pose=np.eye(4))
    lamps = {}
    for k, c in (('amber', [1.0, 0.6, 0.15]), ('green', [0.35, 1.0, 0.55])):
        sm = trimesh.creation.icosphere(subdivisions=2, radius=0.07)
        mat = pyrender.MetallicRoughnessMaterial(baseColorFactor=[0, 0, 0, 1], emissiveFactor=c)
        lamps[k] = sc.add(pyrender.Mesh.from_trimesh(sm, material=mat), pose=FAR)
    return sc, rover, bnode, lamps

FAR = np.r_[np.c_[np.eye(3), [0, -9999, 0]], [[0, 0, 0, 1]]]

def HAND_W():
    return np.array([HAND[0], hgt(HAND[0], HAND[1])[0], HAND[1]])
